# Iproduce Digital Twin development toolkit
The docker setup for the first digital twin project ICE produced.

## Table of content
- [Iproduce Digital Twin development toolkit](#iproduce-digital-twin-development-toolkit)
  - [Table of content](#table-of-content)
  - [Getting Started](#getting-started)
    - [Prerequisites](#prerequisites)
    - [Running the Digital Twin development tool kit](#running-the-digital-twin-development-tool-kit)


## Getting Started

### Prerequisites
Make sure you have installed all of the following prerequisites:

* Docker (if you are unfamiliar with Docker, I recommend referring to the Docker documentation for a comprehensive guide on how to utilize Docker effectively.) - [Install Docker](https://docs.docker.com/get-docker/) 
* Docker Compose - [Install Docker Compose](https://docs.docker.com/compose/install/) 

### Running the Digital Twin development tool kit
This section provides information on how to set up the local deployment using Docker.

Start/run the docker-compose file to run the digital twin development kit services.
`$ docker-compose up`
The above command will take a few minutes to run, depending on the resources available.

Check `docker-compose.yml` to find Port mappings.
* [http://localhost:7080/](http://localhost:7080/) - Four panel landing page
* [http://localhost:7063/](http://localhost:7063/) - Kafka web dashboard


For more detailed information and access to the complete documentation, please navigate to the "DOCUMENTATION" folder and execute the command $ docker-compose up. Afterwards, proceed to the following location: [http://localhost:8000/](http://localhost:8000/) 
