# Get Started

## Overview
This guide serves as a comprehensive resource for utilizing the Digital Twin Development tool kit, providing detailed, 

* step-by-step instructions on getting started with the tool. The guide includes information on initiating the tool kit
* An overview of the various tools available within the tool kit
* Guidance on running the example Digital Twin created by the development team. 

The guide is designed to assist users in understanding the capabilities and functionality of the Digital Twin Development tool kit, and to facilitate the successful implementation of the tool kit in various projects.

## What is a digital Twin

A Digital Twin is a digital replica of a physical entity, such as a machine or a product, that allows for the simulation in a virtual environment. By creating a Digital Twin, it is possible to test and experiment with different scenarios, such as changes in design, or usage, in order to improve the efficiency of the physical entity. This can be done before any physical changes are made, which can save time, money and avoid any potential issues.

## System requirements

The Digital Twin Development Tool Kit is compatible with all major operating systems. In order to run it successfully on a computer, certain requirements must be met.

### Windows
* Windows 10 64-bit: Home or Pro 21H1 (build 19043) or higher, or Enterprise or Education 20H2 (build 19042) or higher.
* [Docker Desktop](https://docs.docker.com/get-docker/)
 (Please fallow documentation in the offcial docker website to install and setup docker desktop)

### Linux
* 64-bit kernel and CPU support for virtualization. (Ubuntu, Debian, Fedora)
* Gnome, KDE, or MATE Desktop environment.
* At least 4 GB of RAM. 
* [Docker](https://docs.docker.com/get-docker/)
 (Please fallow documentation in the offcial docker website to install and setup docker desktop)


## Set up Digital twin development toolkit

* Clone this repository - [https://github.com/information-catalyst/iproduce-digital-twin-kit](https://github.com/information-catalyst/iproduce-digital-twin-kit)
* Extract the zip file (Digital-Twin-Kit.zip) 
* Run the Docker-compose file using the command - `docker-compose up -d`
* Visit this URL to access the main page of the digitaltiwn development toolkit - [http://localhost:7080/](http://localhost:7080/) 



## Explore main components

When runing the digital twin development toolkit, something similar to the following will be displayed.

![Digital Twin development toolkit](./images/dt-screenshot-full.png "The 3D Model (3D world)")

### Reload and zoom  buttons

A reload button can be found in each quadrant, which is utilized to reload the individual component. Additionally, a zoom button is provided to allow for zooming within the quadrant.

