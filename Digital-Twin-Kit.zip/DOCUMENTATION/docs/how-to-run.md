## How to run
1. Visit the status page at http://localhost:7073/factory/StatusPage.html and begin consuming all the topics from Kafka. Remember to click on all the buttons.
<br>
![consume topics](../images/consumedata1.jpg "consume topics")
![consume topics](../images/consume%20data.jpg "consume topics")

2. Go to the landing page of the digital twins at http://localhost:7080/. You will see an image like this.
![DT development kit](../images/full.png "DT development kit")

3. Select the correct digital twin by clicking the button in the first quadrant. You can also click the "Test 3D" button to test the animations.
<br>
![Buttons](../images/buttons.jpg "Buttons")

4. Now, go to the second quadrant and log in to the Grafana dashboard by providing the username and password. You can click the zoom button to make the window bigger.
```UN: admin```
```Password: passwrod``` (If you need to change the password, you can do so from the docker-compose file.)

5. Now, go to the data source section and select the correct data source.
```settings->data sources ``` Then, select "kafkamysql" and change the host to the correct host, which in this case should be "kafkamysql." Once that is done, you can click the reload button next to the zoom button, and it will load the proper dashboard for the digital twin.
<br>
![grafana](../images/grafana1.jpg "grafana")
![grafana](../images/grafana2.jpg "grafana")

6. Now open and run the DigitalTwin Animator. This will serve as the physical machine if you don't have a physical machine connected to the DT yet. To run it, navigate to the project root folder and proceed to the DigitalTwinAnimator folder. Run the command ```python guibpmn.py``` Next, select the desired BPMN file to execute and specify the average times for the tasks. Once this is completed, click "Run" and proceed to the digital twin landing page in your web browser.
<br>
![animator](../images/bpmnselect.jpg "animator")
![animator](../images/animator.jpg "animator")

7. Select the appropriate process from the bottom-left corner dropdown and click on "Start."
<br>
![animator](../images/process.jpg "animator")


<iframe width="100%" height="500" src="https://www.youtube.com/embed/D3d0VviCzGI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

