# New digital tiwn

## Pre requisites

* The 3D model needs to be prepared and exported in JSON format from the three.js editor. Please refer to the [documentation](../3D-model/threeJs.md) for further guidance on this.
* An installation of a code editing software (IDE), such as [VS Code](https://code.visualstudio.com/), is required.
* Some level of familiarity with programming in JavaScript, Docker, and Grafana is required. If you are not familiar with these concepts, they can be easily learned.
* The basic concepts of how animations work in [three.js](https://threejs.org/docs/) should be explored.


## Run the tool kit

* Clone this repository - [https://github.com/information-catalyst/iproduce-digital-twin-kit](https://github.com/information-catalyst/iproduce-digital-twin-kit)
* Extract the zip file (Digital-Twin-Kit.zip) 
* Run the Docker-compose file using the command - `docker-compose up -d`
* Visit this URL to access the main page of the digitaltiwn development toolkit - [http://localhost:7080/](http://localhost:7080/) 



After completing the above steps, the project should be opened in your preferred IDE, where you will observe a project structure similar to this.

![file view](../images/dt1.jpg "project structure")

The project structure includes the following:

* The "processes" folder, which contains some sample processes.
* The "volumes/web3d/js" folder, which contains the main JavaScript file for the animations.
* The "models" folder, which houses the 3D models.


## Upload the 3D model


To upload the 3D model, go to the link - [http://localhost:8888/](http://localhost:8888/)  and follow the instructions after clicking on the "Upload 3D model" button.

![upload 3D model](../images/4.PNG "upload 3D model")
![upload 3D model](../images/5.PNG "upload 3D model")


### Delete the 3D model
If a 3D model needs to be deleted, it can be accomplished by clicking the cross icon and removing it.
![delete 3D model](../images/6.PNG "delete 3D model")
![delete 3D model](../images/7.PNG "delete 3D model")


Once a 3D model is uploaded, it will become available in the models folder.

## Creating a new DT in the list

You need to open the file taskList.js in the volumes/web3d/js folder in your IDE, where you will find an example implemented for the small factory digital twin. It can be either updated or deleted, and a new one can be written from scratch. Below is the provided modelList along with the example.


```
var modelList = {
  7: {
    //small factory
    
    pathToJsonObj: "models/3DSmallFactory12.json",
    objName: "FTFactory",
    objPosision: {
      x: 0,
      y: 0.11,
      z: 0,
    },
    objScale: {
      x: 0.1,
      y: 0.1,
      z: 0.1,
    },
    posMarkers: [
      "position_a1_start",
      "position_a1_end",
      "position_a2_start",
      "position_a2_end",
      "position_b1_start",
      "position_b1_end",
      "position_b2_start",
      "position_b2_end",
      "position_a1_contact",
      "position_b1_contact",
      "position_camera_start",
    ],
    callBackFunction: initFactory2Model,
    tasksList: {
      Task_crane_MoveToConveyorB: craneMoveToConveyorB,
      Task_crane_PickupWhiteState: cranePickupWhiteState,
      Task_crane_MoveToConveyorA: craneMoveToConveyorA,
      Task_crane_DropState: craneDropState,
      Task_crane_ResetState: craneResetState,
      Task_conveyora_StartBeltA1: craneStartBeltA1,
      Task_conveyora_PushAState: cranePushAState,
      Task_conveyora_ResetAState: craneResetAState,
      Task_conveyora_StartBeltA2: conveyoraStartBeltA2,
      Task_conveyora_ToolAState: conveyoraToolAState,
      Task_conveyora_SlowBeltA2: conveyoraSlowBeltA2,
      Task_conveyorb_StartBeltB1: conveyorbStartBeltB1,
      Task_conveyora_StopBeltA2: conveyoraStopBeltA2,
      Task_conveyorb_ConveyorBPush: conveyorbConveyorBPush,
      Task_conveyorb_ResetBState: conveyorbResetBState,
      Task_conveyorb_StartBeltB2: conveyorbStartBeltB2,
    }
  }
};
```

The description for each key in the list is provided below.


#### ```objName```
This represents the title of the 3D object. You have the freedom to assign any desired name to the 3D model.

#### ```pathToJsonObj```
This is the location of the 3D model file in JSON format. After you upload the 3D model, it will be stored in the 'models' folder. Make sure to provide the correct path to locate the model.

#### ```objPosision```
The position of the object should have all x, y, and z coordinates set to 0. However, if the 3D object is not correctly positioned, slight adjustments may be necessary

#### ``` objScale ```

The scale of the 3D object.

#### ```posMarkers```

PosMakers, also referred to as position markers, are small 3D objects that can be incorporated into your 3D model. They serve a useful purpose when you require the precise position of a specific location within the 3D world. However, when rendering the 3D model in the world, these markers should remain hidden. Therefore, you need to include any elements that should be concealed in the 3D world within this array. If there are no such elements, leave the array empty.

#### ```callBackFunction```
The callback function is the initial function executed immediately after the 3D model is loaded into the 3D world. You can provide a custom callback function and perform any necessary actions once the 3D model has finished loading. If there are no specific actions required after the 3D model is loaded, leave this field as ```null```.

#### ```tasksList```

This encompasses all the tasks or processes that require animation. You have the flexibility to add as many tasks as needed. The key can be any relevant identifier for the task, while the value corresponds to the function containing the necessary code to animate that specific process or task. you can check the available example in the taskList.js file

Here's an example of a function that can animate the crane in the given example. For more information on utilizing Three.js, please refer to their official documentation. you can add this functions also in the same taskList.js file

```
function craneDropState() {
  var counter = glScene.getObjectByName("product_counter");
  var craneElevation = glScene.getObjectByName("craneArmElevation");
  var conveyorGroup = glScene.getObjectByName("ConveyorGroup");
  if (craneElevation.position.y > -12) {
    craneElevation.position.y -= 0.15;
    return false;
  }
  craneElevation.position.y = -12;
  reparentObject3D(counter, conveyorGroup);
  var position_a1_start = glScene.getObjectByName("position_a1_start");
  return objectMoveTo(
    "product_counter",
    position_a1_start.position.x,
    position_a1_start.position.y,
    position_a1_start.position.z
  );
}
```

After writing all the animations (Or you can do the same thing to test your animations as well), you can proceed to the main landing page and refresh it. If you encounter any caching issues, you may need to clear the cache or press Ctrl+F5. Next, select your 3D model from the top left quadrant and click the "TEST 3D" button. You will see your animations are working.
![3D World](../images/3d-world.png "The 3D Model (3D world)")


## Creating a new BPMN file for the model


Please open the BPMN editor we provide with the toolkit by using this link: http://localhost:8080/.
To get started, create a BPMN file for the tasks you want to animate. You can find sample BPMN files in the toolkit or refer to the BPMN documentation for more guidance.
When creating the BPMN file, remember to use the task's ID as the key in the tasklist.js file. This key is what connects the task to the 3D model.

![task list](../images/tl1.jpg "task list")
![task list](../images/tl2.jpg "task list")

Once done you can click the export button and then EXPORT to BPMN-file. then go to the link - [http://localhost:8888/](http://localhost:8888/)  and follow the instructions after clicking on the "Upload BPMN" button. Please remember to provide the name of the BPMN file

![upload BPMN](../images/dash.jpg "upload BPMN")



