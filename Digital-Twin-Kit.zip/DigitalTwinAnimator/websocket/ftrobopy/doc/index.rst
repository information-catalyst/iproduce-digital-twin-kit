.. ftrobopy documentation master file

ftrobopy - Ansteuerung des fischertechnik TXT Controllers in Python
===================================================================

.. toctree::
   :maxdepth: 0

ftrobopy - ftrobopy
===================

.. autoclass:: ftrobopy.ftrobopy
   :members:
   :noindex:

ftrobopy - ftTXT Basisklasse
============================

.. autoclass:: ftrobopy.ftTXT
   :members:
   :noindex:


