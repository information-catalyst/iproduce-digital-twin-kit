# ThreeJs

This documentation is intended to serve as a guide for the creation of a new 3D model through the use of the ThreeJS editor. 

## What is ThreeJS

The ThreeJS library is utilized to display 3D models on web pages. This cross-browser JavaScript library and application programming interface (API) provides the capability to create and exhibit animated 3D computer graphics in a web browser through the use of WebGL.

[https://threejs.org/](https://threejs.org/)


## ThreeJs editor

The ThreeJS Editor is a tool for creating and visualizing 3D scenes and animations directly in the browser. It utilizes the ThreeJS library, which provides a rich and versatile API for 3D graphics, and enables users to easily manipulate and edit their scenes without the need for complex programming knowledge. 

[https://threejs.org/editor/](https://threejs.org/editor/)

The creation of 3D models for the Digital Twin Development Tool Kit is achieved through the utilization of the ThreeJS Editor. However, should a pre-existing 3D file be available, the ThreeJS Editor can be used to export it in the JSON format for compatibility with the Digital Twin.

### How to import and export 3D models using ThreeJs Editor

In order to utilize a 3D file within the Digital Twin Development Tool Kit, the file must be in JSON format. This can be accomplished through the export of the 3D model using the ThreeJS Editor, or by first importing the model into the ThreeJS Editor (If it is created from another software), and then exporting it in the JSON format. 

#### Import 3D files to the ThreeJs editor.

The recommended format for importation of assets into the ThreeJS Editor is the GL Transmission Format (glTF). If this format is not available, alternative formats including FBX, OBJ, or COLLADA can also be employed.

To utilize the ThreeJS Editor to import and modify a 3D model, the following steps should be taken:

* Open the ThreeJS Editor in a web browser at the URL - [https://threejs.org/editor/](https://threejs.org/editor/)
* Select the "File" option, and then choose "Import".
* Choose the desired 3D model file, which can be in any of the formats mentioned (glTF, FBX, OBJ, or COLLADA).
* Direct modifications to the 3D model can be made within the ThreeJS Editor.

![Import 3D files](../images/sc1.jpg "Import 3D files")


#### Export 3D files in JSON format

To export a 3D file in JSON format from the ThreeJS Editor, the following steps should be followed:

* Open the ThreeJS Editor in a web browser at the URL - [https://threejs.org/editor/](https://threejs.org/editor/)
* Load the desired 3D model into the ThreeJS Editor.
* Select the "File" option, and then choose "Export Object".
* Choose the "JSON" format as the desired export format.
* Select a location to save the exported file, and then click "Export".

<mark>Note: Ensure that the exported file has the '.json' extension to correctly represent the JSON format.<mark>


![Export 3D files](../images/sc2.jpg "Export 3D files")







