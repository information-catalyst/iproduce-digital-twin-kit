ftrobopy - a python module for the fischertechnik TXT controller

runs with python2 (>2.7) and python3

manual.pdf is available in german only

