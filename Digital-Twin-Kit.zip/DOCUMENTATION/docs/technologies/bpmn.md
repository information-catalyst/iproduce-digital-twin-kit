# BPMN

## What is BPMN

The Business Process Modeling Notation, commonly referred to as BPMN, has been developed for the purpose of facilitating the depiction of complex business processes in a manner that is easily comprehensible. The BPMN Business Process Diagram is designed with user-friendliness in mind.

In order to establish a digital twin, the creation of a BPMN file is necessary for the representation of the processes and their corresponding sequences. Further information regarding the diagram elements and symbols utilized in BPMN can be obtained by visiting the specified URL.

[https://www.lucidchart.com/pages/bpmn#section_3](https://www.lucidchart.com/pages/bpmn#section_3)


### Adding processes
At the moment, processes are not getting added automatically. You have to add them manually. We use [BaseX](https://basex.org/) XML database to store all the processes. 

* BaseX documentation - [https://docs.basex.org/wiki/Main_Page](https://docs.basex.org/wiki/Main_Page) 
* BaseX REST API documentation - [https://docs.basex.org/wiki/REST](https://docs.basex.org/wiki/REST) 

Bellow [Curl](https://curl.se/) command-line tool  is used to send the HTTP requests. You can use [postman](https://www.postman.com/) also.

Create the database `Factory_Processes` using rest APIs.

>BaseX Username: admin
>BaseX Password: admin

```curl -X POST \
  http://localhost:8984/rest \
  -H 'authorization: Basic YWRtaW46YWRtaW4=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: text/xml' \
  -d '<commands>
  <create-db name='\''Factory_Processes'\''/>
  <info-db/>
</commands>'
```

Store the process in the database

>You can find a sample process in `/processes` directory

```curl -X PUT \
  http://localhost:8984/rest/Factory_Processes/<process-name> \
  -H 'authorization: Basic YWRtaW46YWRtaW4=' \
  -H 'cache-control: no-cache' \
  -H 'content-type: application/xml' \
  -d '<xml body>'
```