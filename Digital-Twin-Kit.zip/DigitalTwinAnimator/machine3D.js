class machine3D{


	function machine3D(){
		self.object3Ds = [];
		self.operations = [];
		// get object positions

	}


	function reset(argument) {
		// body...
		// reset object3Ds
	}


	function animate(argument) {
		// body...
	}

	// operations
	function resetSlow(argument) {
		// body...




	}



}